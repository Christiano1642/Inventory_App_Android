package com.example.project_two;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.Manifest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 100;
    private Button requestPermissionBtn, sendSmsBtn;
    private String phoneNumber = "1234567890"; // Replace with actual number
    private String message = "This is your SMS alert notification!";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        requestPermissionBtn = findViewById(R.id.requestPermissionBtn);
        sendSmsBtn = findViewById(R.id.sendSmsBtn);
        sendSmsBtn.setVisibility(View.GONE); // Hide send button until permission is granted

        requestPermissionBtn.setOnClickListener(v -> checkSmsPermission());
        sendSmsBtn.setOnClickListener(v -> sendSmsNotification());
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            enableSmsFeature();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    private void enableSmsFeature() {
        Toast.makeText(this, "SMS Permission Granted!", Toast.LENGTH_SHORT).show();
        sendSmsBtn.setVisibility(View.VISIBLE); // Show SMS button
    }

    private void sendSmsNotification() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Sending Failed!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableSmsFeature();
            } else {
                Toast.makeText(this, "Permission Denied! App will work without SMS.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
