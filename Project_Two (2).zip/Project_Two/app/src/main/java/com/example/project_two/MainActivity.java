package com.example.project_two;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper db;
    TextView dataView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        dataView = findViewById(R.id.dataView);
        Button logoutBtn = findViewById(R.id.logoutBtn);
        Button addItemBtn = findViewById(R.id.addItemBtn);

        displayData();

        logoutBtn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
        });

        addItemBtn.setOnClickListener(v -> {
            db.insertData("Sample Item", "10");
            displayData();
        });
    }

    private void displayData() {
        Cursor cursor = db.getAllData();
        StringBuilder builder = new StringBuilder();
        while (cursor.moveToNext()) {
            builder.append("Item: ").append(cursor.getString(1)).append(", Quantity: ")
                    .append(cursor.getString(2)).append("\n");
        }
        dataView.setText(builder.toString());
    }
}
